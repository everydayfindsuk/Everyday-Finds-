EVERYDAY FINDS UK WEBSITE

1. Open index.html in a browser to preview the site.
2. Replace YOUR-EMAIL-HERE with your email address.
3. Replace the three example '#' buttons with your real affiliate/product links after your Amazon Associates account is approved.
4. Upload index.html to a web host that gives you a public website address.
5. Use that public website address for Pinterest/business verification where required.

IMPORTANT:
Do not claim Amazon affiliation or use Amazon logos until your relevant account/program approval and branding rules allow it.
